#!/bin/sh
autoreconf -i && rm -rf autom4te.cache
